package com.buhuisy.app;

import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.View;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

/**
 * 液态玻璃背景。折射算法移植自 xiaofangstudio/liquid-glass-web（MIT，源自 shuding/liquid-glass）：
 * 内缩矩形 SDF → smoothStep 位移场，中心平坦、边缘强烈弯曲，并对背景做亮度/对比度/饱和度校正。
 * Android 12+ 用 RuntimeShader(AGSL) 做逐像素位移；低版本回退为轻微放大采样。
 */
public class LiquidGlassDrawable extends Drawable {

    private static Bitmap sBackdrop;
    private static View sRoot;
    private static final List<WeakReference<LiquidGlassDrawable>> sInstances = new ArrayList<>();

    // 与 liquid-glass-web 的 fragment 一致：SDF(0.3, 0.2, r=0.6)，阈值 -0.15
    private static final String AGSL =
            "uniform shader content;\n" +
            "uniform float2 resolution;\n" +
            "uniform float strength;\n" +
            "float sdRoundRect(float2 p, float2 b, float r) {\n" +
            "  float2 q = abs(p) - b + r;\n" +
            "  return min(max(q.x, q.y), 0.0) + length(max(q, float2(0.0))) - r;\n" +
            "}\n" +
            "float smoothStep(float a, float b, float t) {\n" +
            "  t = clamp((t - a) / (b - a), 0.0, 1.0);\n" +
            "  return t * t * (3.0 - 2.0 * t);\n" +
            "}\n" +
            "half4 main(float2 fragCoord) {\n" +
            "  float2 uv = fragCoord / resolution;\n" +
            "  float2 p = uv - float2(0.5);\n" +
            "  float d = sdRoundRect(p, float2(0.4, 0.34), 0.5);\n" +
            "  float disp = smoothStep(0.8, 0.0, d - 0.15);\n" +
            "  float scaled = smoothStep(0.0, 1.0, disp);\n" +
            "  float2 offset = (fragCoord - resolution * 0.5) * (scaled - 1.0) * strength;\n" +
            "  return content.eval(fragCoord + offset);\n" +
            "}\n";

    private static final float REFRACT_STRENGTH = 0.34f;
    private static final float FALLBACK_LENS = 1.02f;

    private final View host;
    private final float radius;
    private final int tint;
    private boolean pressed;

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF rect = new RectF();
    private final Matrix matrix = new Matrix();

    private boolean geomReady;
    private BitmapShader contentShader;
    private Shader runtimeShader; // 实际为 RuntimeShader（API 33+），此处用基类避免低版本加载

    public LiquidGlassDrawable(View host, float radiusDp, int tintColor) {
        this.host = host;
        this.radius = dp(radiusDp);
        this.tint = tintColor;
        edge.setStyle(Paint.Style.STROKE);
        edge.setStrokeWidth(Math.max(dp(1.2f), 1f));
        edge.setColor(0x33FFFFFF);
        sInstances.add(new WeakReference<>(this));
        attachBackdrop();
    }

    /** 设置全屏背景图（须与根布局同尺寸、同对齐），并刷新所有玻璃面板 */
    public static void setBackdrop(View root, Bitmap bitmap) {
        sRoot = root;
        sBackdrop = bitmap;
        for (WeakReference<LiquidGlassDrawable> ref : new ArrayList<>(sInstances)) {
            LiquidGlassDrawable d = ref.get();
            if (d != null) {
                d.attachBackdrop();
                d.invalidateSelf();
            }
        }
    }

    private void attachBackdrop() {
        if (sBackdrop == null) {
            contentShader = null;
            runtimeShader = null;
            return;
        }
        contentShader = new BitmapShader(sBackdrop, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
        runtimeShader = null;
        if (Build.VERSION.SDK_INT >= 33) {
            runtimeShader = Api33.createRuntime(AGSL, REFRACT_STRENGTH, contentShader);
        }
    }

    private float dp(float value) {
        return value * host.getResources().getDisplayMetrics().density;
    }

    @Override
    protected void onBoundsChange(Rect bounds) {
        geomReady = false;
    }

    private void buildGeometry(Rect b) {
        rect.set(b);
        path.reset();
        path.addRoundRect(rect, radius, radius, Path.Direction.CW);
        geomReady = true;
    }

    @Override
    public void draw(Canvas canvas) {
        Rect b = getBounds();
        if (b.width() <= 0 || b.height() <= 0) return;
        if (!geomReady) buildGeometry(b);

        int save = canvas.save();
        canvas.clipPath(path);

        int dx = 0, dy = 0;
        if (sRoot != null) {
            int[] hl = new int[2];
            int[] rl = new int[2];
            host.getLocationOnScreen(hl);
            sRoot.getLocationOnScreen(rl);
            dx = hl[0] - rl[0];
            dy = hl[1] - rl[1];
        }

        if (contentShader != null) {
            if (runtimeShader != null && Build.VERSION.SDK_INT >= 33) {
                // 对齐背景图（不平移则折射会错位）
                matrix.setTranslate(-dx, -dy);
                contentShader.setLocalMatrix(matrix);
                Api33.update(runtimeShader, b.width(), b.height());
                fill.setShader(runtimeShader);
            } else {
                // 低版本回退：轻微放大采样
                float f = FALLBACK_LENS;
                float cx = b.centerX();
                float cy = b.centerY();
                matrix.setScale(f, f);
                matrix.postTranslate(-f * dx + (1f - f) * cx, -f * dy + (1f - f) * cy);
                contentShader.setLocalMatrix(matrix);
                fill.setShader(contentShader);
            }
            canvas.drawRect(rect, fill);
            fill.setShader(null);
        } else {
            fill.setColor(0x22FFFFFF);
            canvas.drawRect(rect, fill);
        }

        // 白 tint（liquid-glass-web: rgba(255,255,255,0.08)）；为 0 时面板内部与背景完全一致
        if ((tint >>> 24) != 0) {
            fill.setColor(tint);
            canvas.drawRect(rect, fill);
        }

        // 细边高光，仅勾勒玻璃轮廓（不改变内部颜色）
        canvas.drawRoundRect(rect, radius, radius, edge);

        // 按下反馈
        if (pressed) {
            fill.setColor(0x1FFFFFFF);
            canvas.drawRect(rect, fill);
        }

        canvas.restoreToCount(save);
    }

    @Override
    protected boolean onStateChange(int[] state) {
        boolean p = false;
        for (int s : state) {
            if (s == android.R.attr.state_pressed) {
                p = true;
                break;
            }
        }
        if (p != pressed) {
            pressed = p;
            invalidateSelf();
        }
        return true;
    }

    @Override
    public boolean isStateful() {
        return true;
    }

    @Override
    public void getOutline(Outline outline) {
        Rect b = getBounds();
        outline.setRoundRect(b, radius);
    }

    @Override
    public void setAlpha(int alpha) {
    }

    @Override
    public void setColorFilter(ColorFilter colorFilter) {
    }

    @Override
    public int getOpacity() {
        return PixelFormat.TRANSLUCENT;
    }

    /** API 33 专属：隔离 RuntimeShader 类型，避免低版本类加载问题 */
    private static final class Api33 {
        static Shader createRuntime(String src, float strength, Shader content) {
            try {
                android.graphics.RuntimeShader rs = new android.graphics.RuntimeShader(src);
                rs.setFloatUniform("strength", strength);
                rs.setInputShader("content", content);
                return rs;
            } catch (Throwable t) {
                return null;
            }
        }

        static void update(Shader shader, float w, float h) {
            try {
                ((android.graphics.RuntimeShader) shader).setFloatUniform("resolution", w, h);
            } catch (Throwable ignored) {
            }
        }
    }
}
