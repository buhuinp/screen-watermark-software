package com.buhuisy.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;

import java.io.File;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * 主界面：
 *  - 顶部“打开/关闭水印”手动按钮；
 *  - 水印文本(可换行)、字号、样式、自定义字体；
 *  - 调色盘以弹出对话框形式悬浮在主界面上方，避免误触；支持取色/亮度/透明度/手动色号/渐变色；
 *  - 所有参数修改实时自动保存（SharedPreferences），悬浮窗打开时同步生效。
 */
public class MainActivity extends Activity {

    // 主界面控件
    private EditText etText;
    private SeekBar sbSize;
    private TextView tvSizeValue;
    private Button btnToggle;
    private Button btnPickFont;
    private TextView tvFontName;
    private TextView btnResetFont;
    private Spinner spStyle;
    private Button btnOpenWheel;
    private View previewMain;
    private TextView tvVersion;
    private ImageView bgImage;
    private GlassNavBar navBar;

    // 背景图接口：每次打开随机返回一张图片
    private static final String BG_URL = "https://t.alcy.cc/ycy";

    // 液态玻璃染色：浅白（普通面板）/ 强调色（主按钮）/ 更淡（输入框）
    // 液态玻璃染色：面板 0（内部与背景一致，仅边缘折射）/ 控件浅白 / 主按钮强调色
    private static final int GLASS_TINT = 0x00000000;
    private static final int GLASS_TINT_CONTROL = 0x12FFFFFF;
    private static final int GLASS_TINT_ACCENT = 0x1A2D9BD7;

    // 调色盘对话框控件（每次打开时重新获取）
    private Dialog colorDialog;
    private ColorWheelView wheel;
    private ValueSliderView valueSlider;
    private SeekBar sbAlpha;
    private TextView tvAlphaValue;
    private EditText etHex;
    private View preview;
    private GlassSwitch switchGradient;

    private static final int REQUEST_PICK_FONT = 1001;

    // 防止程序回填 hex 时触发自身 TextWatcher 造成死循环
    private boolean updatingHex = false;

    // 本地期望状态：true=水印开启
    private boolean watermarkOn = false;

    // 申请“所有文件权限”返回后自动打开字体选择器
    private boolean pendingOpenPicker = false;

    // 初始化样式下拉时抑制自动回调
    private boolean suppressSpinner = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            installCrashLogger();
            setContentView(R.layout.activity_main);
            enableEdgeToEdge();

            bgImage = findViewById(R.id.bgImage);
            loadBackgroundImage();

            etText = findViewById(R.id.etText);
            sbSize = findViewById(R.id.sbSize);
            tvSizeValue = findViewById(R.id.tvSizeValue);
            btnToggle = findViewById(R.id.btnToggle);
            btnPickFont = findViewById(R.id.btnPickFont);
            tvFontName = findViewById(R.id.tvFontName);
            btnResetFont = findViewById(R.id.btnResetFont);
            spStyle = findViewById(R.id.spStyle);
            btnOpenWheel = findViewById(R.id.btnOpenWheel);
            previewMain = findViewById(R.id.previewMain);
            tvVersion = findViewById(R.id.tvVersion);

            // 水印文本
            etText.setText(Prefs.getText(this));
            updateFontLabel();

            // 字号
            int fontSize = Prefs.getFontSize(this);
            sbSize.setProgress(fontSize - 8);
            tvSizeValue.setText(fontSize + "dp");

            // 样式下拉
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                    this, R.array.watermark_styles, android.R.layout.simple_spinner_item);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spStyle.setAdapter(adapter);
            suppressSpinner = true;
            spStyle.setSelection(Prefs.getStyle(this));
            suppressSpinner = false;

            // 主界面当前颜色预览
            previewMain.setBackgroundColor(0xFF000000 | (Prefs.getColor(this) & 0xFFFFFF));

            // 版本号（关于页内）
            try {
                String version = getPackageManager()
                        .getPackageInfo(getPackageName(), 0).versionName;
                tvVersion.setText("v" + version);
            } catch (Exception ignored) {
            }

            // 底栏：主页 / 关于
            wireBottomBar();
            wireMainListeners();
            applyGlassStyle();
        } catch (Throwable t) {
            showError(t);
        }
    }

    /** 把未捕获的崩溃写入 /data/data/<包名>/files/crash.log，便于排查 */
    private void installCrashLogger() {
        try {
            final Thread.UncaughtExceptionHandler def =
                    Thread.getDefaultUncaughtExceptionHandler();
            Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
                @Override
                public void uncaughtException(Thread thread, Throwable throwable) {
                    try {
                        java.io.PrintWriter pw = new java.io.PrintWriter(
                                openFileOutput("crash.log", MODE_APPEND));
                        throwable.printStackTrace(pw);
                        pw.close();
                    } catch (Exception ignored) {
                    }
                    if (def != null) def.uncaughtException(thread, throwable);
                    else android.os.Process.killProcess(android.os.Process.myPid());
                }
            });
        } catch (Throwable ignored) {
        }
    }

    /** 出错时不再闪退，直接显示错误信息 */
    private void showError(Throwable t) {
        try {
            java.io.StringWriter sw = new java.io.StringWriter();
            t.printStackTrace(new java.io.PrintWriter(sw));

            TextView tv = new TextView(this);
            tv.setTextSize(14f);
            tv.setTextColor(0xFFCC0000);
            tv.setText("启动出错（已显示错误，不再闪退）：\n\n" + t + "\n\n" + sw.toString());

            android.widget.ScrollView sv = new android.widget.ScrollView(this);
            sv.addView(tv);
            setContentView(sv);
        } catch (Throwable ignored) {
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!hasOverlayPermission()) {
            requestOverlayPermission();
        }
        watermarkOn = FloatingWatermarkService.isRunning();
        updateToggleButton();
        if (pendingOpenPicker) {
            pendingOpenPicker = false;
            openFontPicker();
        }
    }

    // ---------- 背景图（随机图片接口） ----------

    /** 让内容铺到状态栏/导航栏下方，配合透明系统栏使背景图铺满全屏 */
    private void enableEdgeToEdge() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                getWindow().setDecorFitsSystemWindows(false);
            } else {
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
            }
        } catch (Throwable ignored) {
        }
    }

    /** 异步拉取随机背景图并铺满主界面；失败则保持纯色背景，不影响其他功能 */
    private void loadBackgroundImage() {
        new Thread(new Runnable() {
            @Override public void run() {
                final Bitmap bmp = downloadBitmap(BG_URL);
                if (bmp == null) return;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (bgImage == null) return;
                        installGlassBackdrop(bmp);
                    }
                });
            }
        }).start();
    }

    private static Bitmap downloadBitmap(String urlStr) {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(urlStr).openConnection();
            conn.setInstanceFollowRedirects(true);
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(15000);
            conn.connect();
            if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) return null;
            InputStream in = conn.getInputStream();
            Bitmap bmp = BitmapFactory.decodeStream(in);
            in.close();
            return bmp;
        } catch (Throwable t) {
            return null;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    /** 生成与根布局对齐的模糊背景位图，供液态玻璃面板采样 */
    private void installGlassBackdrop(final Bitmap src) {
        View root = findViewById(R.id.rootLayout);
        if (root == null) return;
        int w = root.getWidth(), h = root.getHeight();
        if (w <= 0 || h <= 0) {
            root.post(new Runnable() {
                @Override public void run() {
                    installGlassBackdrop(src);
                }
            });
            return;
        }
        Bitmap backdrop = makeBackdrop(src, w, h);
        if (backdrop != null) {
            // 背景显示与玻璃采样用同一张位图，避免面板与背景产生色差
            bgImage.setImageBitmap(backdrop);
            bgImage.setVisibility(View.VISIBLE);
            LiquidGlassDrawable.setBackdrop(root, backdrop);
        }
    }

    private static Bitmap makeBackdrop(Bitmap src, int w, int h) {
        try {
            int tw = Math.max(1, w / 3);
            int th = Math.max(1, h / 3);
            float s = Math.max((float) tw / src.getWidth(), (float) th / src.getHeight());
            float dw = src.getWidth() * s;
            float dh = src.getHeight() * s;

            Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);

            // 先缩到 1/6 尺寸（模糊），再放大回屏幕尺寸，避开大图中间位图
            Bitmap tiny = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888);
            Canvas tinyCanvas = new Canvas(tiny);
            Matrix m = new Matrix();
            m.setScale(s, s);
            m.postTranslate((tw - dw) / 2f, (th - dh) / 2f);
            tinyCanvas.drawBitmap(src, m, paint);

            Bitmap blur = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(blur);
            canvas.drawBitmap(tiny, null, new Rect(0, 0, w, h), paint);
            // 把遮罩压暗盖进采样图，保证玻璃与背景亮度一致
            canvas.drawColor(0x66000000);
            return blur;
        } catch (Throwable t) {
            return null;
        }
    }

    // ---------- 液态玻璃样式 ----------

    private void applyGlassStyle() {
        glass(findViewById(R.id.navBar), 32, GLASS_TINT_CONTROL, 8);
        glass(findViewById(R.id.cardText), 16, GLASS_TINT, 6);
        glass(findViewById(R.id.cardStyle), 16, GLASS_TINT, 6);
        glass(findViewById(R.id.cardFont), 16, GLASS_TINT, 6);
        glass(findViewById(R.id.cardColor), 16, GLASS_TINT, 6);
        glass(findViewById(R.id.cardDev), 16, GLASS_TINT, 6);
        glass(findViewById(R.id.cardFeatures), 16, GLASS_TINT, 6);
        glass(findViewById(R.id.cardLegal), 16, GLASS_TINT, 6);
        glassInset(findViewById(R.id.etText));
        glass(findViewById(R.id.btnToggle), 12, GLASS_TINT_CONTROL, 4);
        if (btnToggle != null) btnToggle.setTextColor(0xFF33B5E5);
        flatten(btnPickFont);
        flatten(btnOpenWheel);
    }

    /** 控件融入卡片：去掉独立底色与边框，仅保留文字 */
    private void flatten(android.widget.TextView v) {
        if (v == null) return;
        v.setBackground(null);
        v.setTextColor(0xFF33B5E5);
    }

    private void glass(View v, float radiusDp, int tint, float elevationDp) {
        if (v == null) return;
        // 关闭 Material 按钮/输入框的默认背景着色，避免盖掉玻璃效果
        v.setBackgroundTintList(null);
        v.setBackground(new LiquidGlassDrawable(v, radiusDp, tint));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            v.setElevation(dp(elevationDp));
        }
    }

    /** 输入框：去掉底色与边框，直接坐在卡片玻璃上 */
    private void glassInset(View v) {
        if (v == null) return;
        v.setBackgroundTintList(null);
        v.setBackground(null);
    }

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }

    // ---------- 悬浮窗权限 ----------

    private boolean hasOverlayPermission() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M
                || Settings.canDrawOverlays(this);
    }

    private void requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Intent intent = new Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                startActivity(intent);
            } catch (Exception ignored) {
            }
        }
    }

    // ---------- 打开/关闭水印按钮 ----------

    private void updateToggleButton() {
        if (btnToggle == null) return;
        if (!hasOverlayPermission()) {
            btnToggle.setText(R.string.btn_request_permission);
        } else if (watermarkOn) {
            btnToggle.setText(R.string.btn_close_watermark);
        } else {
            btnToggle.setText(R.string.btn_open_watermark);
        }
    }

    private void toggleWatermark() {
        if (!hasOverlayPermission()) {
            requestOverlayPermission();
            return;
        }
        if (watermarkOn) {
            try {
                stopService(new Intent(MainActivity.this, FloatingWatermarkService.class));
            } catch (Exception ignored) {
            }
            watermarkOn = false;
        } else {
            try {
                startService(new Intent(MainActivity.this, FloatingWatermarkService.class));
            } catch (Exception ignored) {
            }
            watermarkOn = true;
        }
        updateToggleButton();
    }

    // ---------- 自定义字体 ----------

    private void pickFont() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R
                && !Environment.isExternalStorageManager()) {
            pendingOpenPicker = true;
            try {
                Intent i = new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } catch (Exception e) {
                pendingOpenPicker = false;
                openFontPicker();
            }
        } else {
            openFontPicker();
        }
    }

    private void openFontPicker() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "font/ttf", "font/otf", "application/x-font-ttf", "application/x-font-opentype"});
        try {
            startActivityForResult(i, REQUEST_PICK_FONT);
        } catch (Exception e) {
            try {
                i.setType("*/*");
                startActivityForResult(i, REQUEST_PICK_FONT);
            } catch (Exception ignored) {
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_PICK_FONT && resultCode == RESULT_OK
                && data != null && data.getData() != null) {
            applyFontFromUri(data.getData());
        }
    }

    private void applyFontFromUri(Uri uri) {
        try {
            InputStream in = getContentResolver().openInputStream(uri);
            if (in == null) return;
            String raw = uri.getLastPathSegment();
            String name = raw == null ? "selected" : raw;
            name = name.replaceAll("[^a-zA-Z0-9._-]", "_");

            File dir = new File(getFilesDir(), "fonts");
            if (!dir.exists()) dir.mkdirs();
            File out = new File(dir, name);

            java.io.FileOutputStream fos = new java.io.FileOutputStream(out);
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) fos.write(buf, 0, n);
            fos.flush();
            fos.close();
            in.close();

            Prefs.setFontPath(this, out.getAbsolutePath());
            FloatingWatermarkService.updateNow();
            tvFontName.setText(name);
        } catch (Exception e) {
            try {
                tvFontName.setText(R.string.font_load_fail);
            } catch (Exception ignored) {
            }
        }
    }

    private void resetFont() {
        Prefs.setFontPath(this, "");
        FloatingWatermarkService.updateNow();
        updateFontLabel();
    }

    private void updateFontLabel() {
        if (tvFontName == null) return;
        String p = Prefs.getFontPath(this);
        if (p == null || p.isEmpty()) {
            tvFontName.setText(R.string.font_default);
        } else {
            File f = new File(p);
            tvFontName.setText(f.exists() ? f.getName() : getString(R.string.font_default));
        }
    }

    // ---------- 底栏（主页 / 关于） ----------

    private void wireBottomBar() {
        final View pageMain = findViewById(R.id.pageMain);
        final View pageAbout = findViewById(R.id.pageAbout);
        navBar = findViewById(R.id.navBar);
        if (navBar == null) return;

        navBar.setSelectedTab(0);
        navBar.setOnTabSelectedListener(new GlassNavBar.OnTabSelectedListener() {
            @Override public void onTabSelected(int index) {
                boolean main = index == 0;
                pageMain.setVisibility(main ? View.VISIBLE : View.GONE);
                pageAbout.setVisibility(main ? View.GONE : View.VISIBLE);
            }
        });
    }

    // ---------- 调色盘对话框 ----------

    /** 打开调色盘：以对话框悬浮在主界面上方，避免误触 */
    private void openColorDialog() {
        try {
            colorDialog = new Dialog(this);
            colorDialog.setContentView(R.layout.dialog_color);
            // 让对话框窗口本身透明，使面板的毛玻璃背景透出主界面
            if (colorDialog.getWindow() != null) {
                colorDialog.getWindow().setBackgroundDrawableResource(
                        android.R.color.transparent);
            }

            wheel = colorDialog.findViewById(R.id.wheel);
            valueSlider = colorDialog.findViewById(R.id.valueSlider);
            sbAlpha = colorDialog.findViewById(R.id.sbAlpha);
            tvAlphaValue = colorDialog.findViewById(R.id.tvAlphaValue);
            etHex = colorDialog.findViewById(R.id.etHex);
            preview = colorDialog.findViewById(R.id.preview);
            switchGradient = colorDialog.findViewById(R.id.switchGradient);
            Button btnClose = colorDialog.findViewById(R.id.btnCloseWheel);

            // 对话框面板、输入框、按钮换成液态玻璃
            glass(colorDialog.findViewById(R.id.dialogRoot), 20, GLASS_TINT_CONTROL, 12);
            glassInset(etHex);
            glass(btnClose, 12, GLASS_TINT_ACCENT, 4);

            int savedColor = Prefs.getColor(this);

            int alpha = (savedColor >>> 24) & 0xFF;
            sbAlpha.setProgress(Math.round(alpha * 100f / 255f));
            tvAlphaValue.setText(Math.round(alpha * 100f / 255f) + "%");

            wheel.setMarker(savedColor);
            valueSlider.setBaseColor(savedColor);
            float[] hsv = new float[3];
            Color.colorToHSV(savedColor, hsv);
            valueSlider.setValueSilent(hsv[2]);
            refreshHexAndPreview(savedColor);

            switchGradient.setChecked(Prefs.getGradientEnabled(this));

            wireColorListeners();

            btnClose.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (colorDialog != null) colorDialog.dismiss();
                }
            });

            colorDialog.show();
        } catch (Throwable t) {
            // 打开调色盘失败不闪退
        }
    }

    // ---------- 主界面回调 ----------

    private void wireMainListeners() {
        btnToggle.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                toggleWatermark();
            }
        });

        etText.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) {
                Prefs.setText(MainActivity.this, s.toString());
                FloatingWatermarkService.updateNow();
            }
        });

        sbSize.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                int dp = progress + 8;
                tvSizeValue.setText(dp + "dp");
                if (fromUser) {
                    Prefs.setFontSize(MainActivity.this, dp);
                    FloatingWatermarkService.updateNow();
                }
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });

        spStyle.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View v, int pos, long id) {
                if (suppressSpinner) return;
                Prefs.setStyle(MainActivity.this, pos);
                FloatingWatermarkService.updateNow();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        btnOpenWheel.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                openColorDialog();
            }
        });

        btnPickFont.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                pickFont();
            }
        });

        btnResetFont.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                resetFont();
            }
        });
    }

    // ---------- 调色盘回调 ----------

    private void wireColorListeners() {
        wheel.setOnColorChangedListener(new ColorWheelView.OnColorChangedListener() {
            @Override public void onWheelChanged(float hue, float sat) {
                applyColorFromControls();
            }
        });

        valueSlider.setOnValueChangedListener(new ValueSliderView.OnValueChangedListener() {
            @Override public void onValueChanged(float value) {
                applyColorFromControls();
            }
        });

        sbAlpha.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                tvAlphaValue.setText(progress + "%");
                if (fromUser) {
                    applyColorFromControls();
                }
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });

        etHex.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) {
                if (updatingHex) return;
                String raw = s.toString();
                Integer argb = parseHex(raw);
                if (argb == null) return;

                String noHash = raw.trim().replace("#", "");
                if (noHash.length() == 8) {
                    int alpha = (argb >>> 24) & 0xFF;
                    sbAlpha.setProgress(Math.round(alpha * 100f / 255f));
                    tvAlphaValue.setText(Math.round(alpha * 100f / 255f) + "%");
                }

                int argbFinal = (alpha() << 24) | (argb & 0xFFFFFF);
                wheel.setMarker(argbFinal);
                valueSlider.setBaseColor(argbFinal);
                float[] hsv = new float[3];
                Color.colorToHSV(argbFinal, hsv);
                valueSlider.setValueSilent(hsv[2]);
                applyColor(argbFinal);
            }
        });

        switchGradient.setOnCheckedChangeListener(new GlassSwitch.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(GlassSwitch v, boolean checked) {
                Prefs.setGradientEnabled(MainActivity.this, checked);
                FloatingWatermarkService.updateNow();
            }
        });
    }

    // ---------- 颜色合成 ----------

    private int alpha() {
        return Math.round(sbAlpha.getProgress() * 255f / 100f);
    }

    private void applyColorFromControls() {
        int rgb = Color.HSVToColor(new float[]{
                wheel.getHue(), wheel.getSat(), valueSlider.getValue()});
        int argb = (alpha() << 24) | (rgb & 0xFFFFFF);
        applyColor(argb);
    }

    private void applyColor(int argb) {
        refreshHexAndPreview(argb);
        Prefs.setColor(this, argb);
        FloatingWatermarkService.updateNow();
    }

    private void refreshHexAndPreview(int argb) {
        if (etHex != null) {
            updatingHex = true;
            etHex.setText(toHex(argb));
            etHex.setSelection(etHex.getText().length());
            updatingHex = false;
        }
        if (preview != null) {
            preview.setBackgroundColor(0xFF000000 | (argb & 0xFFFFFF));
        }
        if (previewMain != null) {
            previewMain.setBackgroundColor(0xFF000000 | (argb & 0xFFFFFF));
        }
    }

    // ---------- hex 解析 ----------

    private static String toHex(int argb) {
        int a = (argb >>> 24) & 0xFF;
        if (a == 0xFF) {
            return String.format("#%06X", argb & 0xFFFFFF);
        }
        return String.format("#%08X", argb);
    }

    private static Integer parseHex(String s) {
        if (s == null) return null;
        String h = s.trim();
        if (h.startsWith("#")) h = h.substring(1);
        if (h.length() != 6 && h.length() != 8) return null;
        try {
            long v = Long.parseLong(h, 16);
            if (h.length() == 6) {
                return 0xFF000000 | (int) v;
            }
            return (int) v;
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
