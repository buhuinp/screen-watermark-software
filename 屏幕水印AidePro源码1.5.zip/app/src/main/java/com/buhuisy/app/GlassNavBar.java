package com.buhuisy.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;

/**
 * 液态玻璃底部导航栏：玻璃胶囊 + 可拖动的选中块。
 * 交互：点击切换；长按选中块放大后可左右拖动，松手吸附到最近页面。
 */
public class GlassNavBar extends View {

    public interface OnTabSelectedListener {
        void onTabSelected(int index);
    }

    private static final int ACCENT = 0xFF33B5E5;
    private static final int NORMAL = 0xFFCFCFCF;
    private static final long LONG_PRESS_MS = 100;
    private static final float PAD_DP = 7f;
    private static final float GROW_SCALE = 0.12f;

    private final String[] labels = {"主页", "关于"};
    private int selected = 0;
    private float indicator = 0f;   // 选中块位置 0..1（拖动时为连续值）
    private float grow = 0f;        // 长按放大 0..1
    private ValueAnimator indicatorAnim;
    private ValueAnimator growAnim;
    private OnTabSelectedListener listener;

    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint selFill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint selEdge = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF selRect = new RectF();

    // 手势
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final int touchSlop;
    private boolean dragging = false;
    private boolean moved = false;
    private float downX, downY;

    private final Runnable longPressRunnable = new Runnable() {
        @Override public void run() {
            dragging = true;
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            animateGrow(1f);
        }
    };

    public GlassNavBar(Context context) {
        super(context);
        touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
        init();
    }

    public GlassNavBar(Context context, AttributeSet attrs) {
        super(context, attrs);
        touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
        init();
    }

    private void init() {
        setClickable(true);
        setFocusable(true);
        selFill.setColor(0x40FFFFFF);
        selEdge.setStyle(Paint.Style.STROKE);
        selEdge.setStrokeWidth(Math.max(dp(1), 1));
        selEdge.setColor(0x77FFFFFF);
    }

    public void setOnTabSelectedListener(OnTabSelectedListener l) {
        this.listener = l;
    }

    public void setSelectedTab(int index) {
        if (index < 0 || index >= labels.length) return;
        selected = index;
        indicator = index;
        invalidate();
    }

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }

    private void animateIndicator(float target) {
        if (indicatorAnim != null) indicatorAnim.cancel();
        indicatorAnim = ValueAnimator.ofFloat(indicator, target);
        indicatorAnim.setDuration(220);
        indicatorAnim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator a) {
                indicator = (float) a.getAnimatedValue();
                invalidate();
            }
        });
        indicatorAnim.start();
    }

    private void animateGrow(float target) {
        if (growAnim != null) growAnim.cancel();
        growAnim = ValueAnimator.ofFloat(grow, target);
        growAnim.setDuration(180);
        growAnim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator a) {
                grow = (float) a.getAnimatedValue();
                invalidate();
            }
        });
        growAnim.start();
    }

    private void commit(int index) {
        boolean changed = index != selected;
        selected = index;
        animateIndicator(index);
        if (changed && listener != null) listener.onTabSelected(index);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        textPaint.setTextSize(dp(16));
        float maxText = 0f;
        for (String s : labels) maxText = Math.max(maxText, textPaint.measureText(s));
        float segW = Math.max(maxText + dp(32), dp(80));
        int desiredW = (int) (segW * 2 + dp(PAD_DP) * 2);
        int desiredH = (int) dp(64);
        setMeasuredDimension(resolveSize(desiredW, widthMeasureSpec),
                resolveSize(desiredH, heightMeasureSpec));
    }

    private float trackLeft() {
        return dp(PAD_DP);
    }

    private float trackRight() {
        return getWidth() - dp(PAD_DP);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float left = trackLeft(), right = trackRight();
        float top = dp(PAD_DP), bottom = getHeight() - dp(PAD_DP);
        if (right <= left || bottom <= top) return;

        float seg = (right - left) / 2f;

        // 选中块：长按时放大
        float growScale = 1f + grow * GROW_SCALE;
        float cx = left + indicator * seg + seg / 2f;
        float cy = (top + bottom) / 2f;
        float pw = seg * growScale;
        float ph = (bottom - top) * growScale;
        float r = ph / 2f;
        selRect.set(cx - pw / 2f, cy - ph / 2f, cx + pw / 2f, cy + ph / 2f);
        canvas.drawRoundRect(selRect, r, r, selFill);
        canvas.drawRoundRect(selRect, r, r, selEdge);

        // 文字
        textPaint.setTextSize(dp(16));
        textPaint.setTextAlign(Paint.Align.CENTER);
        Paint.FontMetrics fm = textPaint.getFontMetrics();
        float baseline = (top + bottom) / 2f - (fm.ascent + fm.descent) / 2f;
        for (int i = 0; i < labels.length; i++) {
            float lcx = left + seg * i + seg / 2f;
            boolean on = i == selected;
            textPaint.setColor(on ? ACCENT : NORMAL);
            textPaint.setFakeBoldText(on);
            canvas.drawText(labels[i], lcx, baseline, textPaint);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = event.getX();
                downY = event.getY();
                moved = false;
                handler.postDelayed(longPressRunnable, LONG_PRESS_MS);
                return true;

            case MotionEvent.ACTION_MOVE: {
                float x = event.getX();
                if (!dragging) {
                    if (Math.abs(x - downX) > touchSlop || Math.abs(event.getY() - downY) > touchSlop) {
                        moved = true;
                        handler.removeCallbacks(longPressRunnable);
                    }
                    return true;
                }
                float left = trackLeft(), right = trackRight();
                float seg = (right - left) / 2f;
                if (seg > 0) {
                    indicator = clamp((x - left - seg / 2f) / seg, 0f, 1f);
                    invalidate();
                }
                return true;
            }

            case MotionEvent.ACTION_UP:
                handler.removeCallbacks(longPressRunnable);
                if (dragging) {
                    int target = indicator < 0.5f ? 0 : 1;
                    animateGrow(0f);
                    dragging = false;
                    commit(target);
                } else if (!moved) {
                    float left = trackLeft(), right = trackRight();
                    float seg = (right - left) / 2f;
                    commit(event.getX() < left + seg ? 0 : 1);
                }
                performClick();
                return true;

            case MotionEvent.ACTION_CANCEL:
                handler.removeCallbacks(longPressRunnable);
                if (dragging) {
                    dragging = false;
                    animateGrow(0f);
                    animateIndicator(selected);
                }
                return true;

            default:
                return super.onTouchEvent(event);
        }
    }

    private static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }
}
