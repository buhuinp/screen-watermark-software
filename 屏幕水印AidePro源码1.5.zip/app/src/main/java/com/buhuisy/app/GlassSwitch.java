package com.buhuisy.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/**
 * 液态玻璃开关：玻璃胶囊轨道 + 玻璃圆钮，选中时轨道染上强调色。
 */
public class GlassSwitch extends View {

    public interface OnCheckedChangeListener {
        void onCheckedChanged(GlassSwitch v, boolean checked);
    }

    private static final int ACCENT = 0xFF33B5E5;

    private boolean checked;
    private float progress; // 0..1
    private ValueAnimator animator;
    private OnCheckedChangeListener listener;

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF track = new RectF();

    public GlassSwitch(Context context) {
        super(context);
        init();
    }

    public GlassSwitch(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        setClickable(true);
        setFocusable(true);
    }

    public void setOnCheckedChangeListener(OnCheckedChangeListener l) {
        this.listener = l;
    }

    public boolean isChecked() {
        return checked;
    }

    public void setChecked(boolean c) {
        setChecked(c, false);
    }

    private void setChecked(boolean c, boolean animate) {
        if (checked == c) return;
        checked = c;
        if (animate) {
            animateTo(c ? 1f : 0f);
        } else {
            progress = c ? 1f : 0f;
            invalidate();
        }
    }

    private void animateTo(float target) {
        if (animator != null) animator.cancel();
        animator = ValueAnimator.ofFloat(progress, target);
        animator.setDuration(180);
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                progress = (float) animation.getAnimatedValue();
                invalidate();
            }
        });
        animator.start();
    }

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int w = (int) dp(56);
        int h = (int) dp(32);
        setMeasuredDimension(resolveSize(w, widthMeasureSpec), resolveSize(h, heightMeasureSpec));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float pad = dp(1.5f);
        track.set(pad, pad, getWidth() - pad, getHeight() - pad);
        float tr = track.height() / 2f;

        // 玻璃轨道
        paint.setShader(new LinearGradient(
                track.left, track.top, track.left, track.bottom,
                0x66FFFFFF, 0x22FFFFFF, Shader.TileMode.CLAMP));
        canvas.drawRoundRect(track, tr, tr, paint);
        paint.setShader(null);

        // 选中时染强调色
        if (progress > 0.01f) {
            int a = (int) (0xB3 * progress);
            paint.setColor((a << 24) | (ACCENT & 0xFFFFFF));
            canvas.drawRoundRect(track, tr, tr, paint);
        }

        // 边缘高光
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(dp(1f), 1f));
        paint.setShader(new LinearGradient(
                track.left, track.top, track.right, track.bottom,
                0xE6FFFFFF, 0x33FFFFFF, Shader.TileMode.CLAMP));
        canvas.drawRoundRect(track, tr, tr, paint);
        paint.setShader(null);
        paint.setStyle(Paint.Style.FILL);

        // 玻璃圆钮
        float thumbR = track.height() / 2f - dp(3);
        float minX = track.left + dp(3) + thumbR;
        float maxX = track.right - dp(3) - thumbR;
        float cx = minX + (maxX - minX) * progress;
        float cy = track.centerY();

        paint.setShader(new RadialGradient(
                cx - thumbR * 0.35f, cy - thumbR * 0.4f, thumbR * 1.8f,
                0xFFFFFFFF, 0xFFDDEBF3, Shader.TileMode.CLAMP));
        canvas.drawCircle(cx, cy, thumbR, paint);
        paint.setShader(null);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(1f));
        paint.setColor(0x99FFFFFF);
        canvas.drawCircle(cx, cy, thumbR, paint);
        paint.setStyle(Paint.Style.FILL);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                return true;
            case MotionEvent.ACTION_UP:
                if (event.getX() >= 0 && event.getX() <= getWidth()
                        && event.getY() >= 0 && event.getY() <= getHeight()) {
                    setChecked(!checked, true);
                    if (listener != null) listener.onCheckedChanged(this, checked);
                    performClick();
                }
                return true;
            default:
                return super.onTouchEvent(event);
        }
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }
}
