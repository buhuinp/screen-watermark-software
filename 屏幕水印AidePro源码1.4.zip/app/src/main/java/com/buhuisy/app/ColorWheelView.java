package com.buhuisy.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/**
 * HSV 调色盘：外圈 0..360° 色相，从圆心到边缘是饱和度。
 * 点击/拖动即可取色；取到的色相+饱和度再与亮度条(ValueSliderView)合成最终颜色。
 */
public class ColorWheelView extends View {

    public interface OnColorChangedListener {
        void onWheelChanged(float hue, float sat);
    }

    private float hue = 200f;   // 0..360
    private float sat = 0.8f;   // 0..1
    private OnColorChangedListener listener;

    private final Paint huePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint satPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint markerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private float cx, cy, radius;

    public ColorWheelView(Context context) {
        super(context);
        init();
    }

    public ColorWheelView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(2f);
        borderPaint.setColor(0xFFAAAAAA);

        markerPaint.setStyle(Paint.Style.STROKE);
        markerPaint.setStrokeWidth(4f);
        markerPaint.setColor(0xFFFFFFFF);
    }

    public void setOnColorChangedListener(OnColorChangedListener l) {
        this.listener = l;
    }

    public float getHue() { return hue; }
    public float getSat() { return sat; }

    /** 根据一个颜色把取色游标移到对应色相/饱和度位置（不触发回调） */
    public void setMarker(int argb) {
        float[] hsv = new float[3];
        Color.colorToHSV(argb, hsv);
        hue = hsv[0];
        sat = hsv[1];
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        cx = w / 2f;
        cy = h / 2f;
        radius = Math.min(w, h) / 2f - 12f;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        try {
            super.onDraw(canvas);
            if (radius <= 0) return;

            // 色相环：SweepGradient 填充 0..360° 的纯色
            int[] hueColors = new int[361];
            float[] hsv = {0f, 1f, 1f};
            for (int i = 0; i <= 360; i++) {
                hsv[0] = i;
                hueColors[i] = Color.HSVToColor(hsv);
            }
            huePaint.setShader(new SweepGradient(cx, cy, hueColors, null));
            canvas.drawCircle(cx, cy, radius, huePaint);

            // 饱和度叠加：圆心白色(饱和0) -> 边缘透明(饱和1)
            satPaint.setShader(new RadialGradient(
                    cx, cy, radius,
                    new int[]{0xFFFFFFFF, 0x00FFFFFF},
                    new float[]{0f, 1f},
                    Shader.TileMode.CLAMP));
            canvas.drawCircle(cx, cy, radius, satPaint);

            canvas.drawCircle(cx, cy, radius, borderPaint);

            // 取色游标
            float angle = (float) ((hue - 90f) * Math.PI / 180f);
            float mx = cx + radius * sat * (float) Math.cos(angle);
            float my = cy + radius * sat * (float) Math.sin(angle);
            canvas.drawCircle(mx, my, 12f, markerPaint);
        } catch (Exception ignored) {
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        try {
            float x = event.getX() - cx;
            float y = event.getY() - cy;
            float dist = (float) Math.sqrt(x * x + y * y);

            float sat0 = 1f;
            if (radius > 0) {
                sat0 = Math.min(1f, Math.max(0f, dist / radius));
            }
            float hue0 = hue;
            if (dist > 0.0001f) {
                double deg = Math.toDegrees(Math.atan2(y, x));
                hue0 = (float) (deg + 90f);
                if (hue0 < 0) hue0 += 360f;
                if (hue0 > 360f) hue0 -= 360f;
            }

            hue = hue0;
            sat = sat0;
            invalidate();
            if (listener != null) {
                listener.onWheelChanged(hue, sat);
            }
        } catch (Exception ignored) {
        }
        return true;
    }
}
