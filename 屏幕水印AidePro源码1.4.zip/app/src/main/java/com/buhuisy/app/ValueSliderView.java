package com.buhuisy.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/**
 * 亮度条：左黑(0) -> 右“当前色相饱和度”的满亮色(1)。
 * 拖动调整 HSV 的 V（明度）。
 */
public class ValueSliderView extends View {

    public interface OnValueChangedListener {
        void onValueChanged(float value);
    }

    private float value = 0.9f;      // V: 0..1
    private float baseHue = 200f;
    private float baseSat = 0.8f;
    private OnValueChangedListener listener;

    private final Paint barPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint markerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    public ValueSliderView(Context context) {
        super(context);
        init();
    }

    public ValueSliderView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(2f);
        borderPaint.setColor(0xFFAAAAAA);

        markerPaint.setColor(0xFFFFFFFF);
        markerPaint.setStyle(Paint.Style.STROKE);
        markerPaint.setStrokeWidth(5f);
    }

    public void setOnValueChangedListener(OnValueChangedListener l) {
        this.listener = l;
    }

    public float getValue() { return value; }

    /** 色相/饱和度变化时调用，刷新渐变底 */
    public void setBaseColor(int argb) {
        float[] hsv = new float[3];
        Color.colorToHSV(argb, hsv);
        baseHue = hsv[0];
        baseSat = hsv[1];
        invalidate();
    }

    /** 设置当前亮度，不触发回调 */
    public void setValueSilent(float v) {
        value = Math.max(0f, Math.min(1f, v));
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        try {
            super.onDraw(canvas);
            int w = getWidth();
            int h = getHeight();
            if (w <= 0 || h <= 0) return;
            float left = 8f, right = w - 8f;
            if (right <= left) right = left + 1f;
            float top = h * 0.25f, bottom = h * 0.75f;
            float midY = (top + bottom) / 2f;

            int fullColor = Color.HSVToColor(new float[]{baseHue, baseSat, 1f});
            barPaint.setShader(new LinearGradient(
                    left, midY, right, midY,
                    new int[]{Color.BLACK, fullColor},
                    null, Shader.TileMode.CLAMP));
            canvas.drawRect(left, top, right, bottom, barPaint);
            canvas.drawRect(left, top, right, bottom, borderPaint);

            float mx = left + (right - left) * value;
            canvas.drawLine(mx, top - 4f, mx, bottom + 4f, markerPaint);
        } catch (Exception ignored) {
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        try {
            float x = Math.max(0f, Math.min(getWidth(), event.getX()));
            float right = Math.max(1, getWidth() - 16f);
            float v = Math.max(0f, Math.min(1f, (x - 8f) / right));
            value = v;
            invalidate();
            if (listener != null) {
                listener.onValueChanged(value);
            }
        } catch (Exception ignored) {
        }
        return true;
    }
}
