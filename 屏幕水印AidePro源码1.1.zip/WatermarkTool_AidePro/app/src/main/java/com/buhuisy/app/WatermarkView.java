package com.buhuisy.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;

import java.io.File;

/**
 * 水印绘制视图：完整还原 dex 中 com.dex.init$WatermarkView 的绘制算法。
 *  1. 颜色 = Color.parseColor(hex)，抗锯齿，字号可调（默认 16dp），字体可自定义
 *  2. onDraw 里将画布绕中心旋转 -45°
 *  3. 支持多行文本（\\n 换行），同一文本块内后续行按第一行居中显示
 *  4. 间距 = 块宽/块高 + 60dp，从 (-宽,-高) 平铺到 (2宽,2高)
 * 它同时被用于悬浮窗覆盖层（全局）显示。
 */
public class WatermarkView extends View {

    private Paint paint;
    private String text;
    private Typeface typeface = Typeface.DEFAULT;

    public WatermarkView(Context context) {
        super(context);
        init(context);
    }

    public WatermarkView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    private void init(Context context) {
        paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        text = Prefs.getText(context);
        // 颜色/字号可被外部 setter 覆盖
        paint.setColor(Prefs.getColor(context));
        paint.setTextSize(dp(context, Prefs.getFontSize(context)));
        paint.setAntiAlias(true);
        paint.setTypeface(typeface);
        // 应用用户自定义字体（若没有则保持默认）
        setWatermarkFont(Prefs.getFontPath(context));
        setClickable(false);
        setFocusable(false);
    }

    /** 更新水印文本（悬浮窗打开时实时生效） */
    public void setWatermarkText(String t) {
        this.text = t;
        invalidate();
    }

    /** 更新水印颜色（ARGB），实时生效 */
    public void setWatermarkColor(int argb) {
        paint.setColor(argb);
        invalidate();
    }

    /** 更新字号（dp），实时生效 */
    public void setWatermarkFontSize(int dp) {
        paint.setTextSize(dp(getContext(), dp));
        invalidate();
    }

    /** 应用自定义字体：path 为空或文件不存在则回退到系统默认字体 */
    public void setWatermarkFont(String path) {
        try {
            Typeface tf = Typeface.DEFAULT;
            if (path != null && !path.isEmpty()) {
                File f = new File(path);
                if (f.exists()) {
                    tf = Typeface.createFromFile(f);
                }
            }
            typeface = tf;
            paint.setTypeface(tf);
            invalidate();
        } catch (Exception ignored) {
            // 字体无效则保持默认，不崩溃
            try {
                paint.setTypeface(Typeface.DEFAULT);
            } catch (Exception ignored2) {
            }
        }
    }

    private float dp(Context ctx, int value) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value,
                ctx.getResources().getDisplayMetrics());
    }

    @Override
    protected void onDraw(Canvas canvas) {
        try {
            super.onDraw(canvas);
            if (text == null || text.isEmpty()) {
                return;
            }

            int w = getWidth();
            int h = getHeight();
            if (w <= 0 || h <= 0) {
                return;
            }

            // 绕中心旋转 -45°，形成斜向平铺
            canvas.rotate(-45f, w / 2f, h / 2f);

            // 拆成多行
            String[] lines = text.split("\\n");
            Paint.FontMetrics fm = paint.getFontMetrics();
            float lineHeight = fm.descent - fm.ascent;
            if (lineHeight <= 0) lineHeight = paint.getTextSize();

            // 文本块宽度 = 最长一行的宽度（通常即第一行），用于让后续行居中
            float blockWidth = 0f;
            for (String line : lines) {
                float lw = paint.measureText(line);
                if (lw > blockWidth) blockWidth = lw;
            }
            float blockHeight = Math.max(lines.length * lineHeight, lineHeight);

            float spacingX = blockWidth + dp(getContext(), 60);
            float spacingY = blockHeight + dp(getContext(), 60);
            if (spacingX <= 0) spacingX = 1f;
            if (spacingY <= 0) spacingY = 1f;

            // 平铺绘制：超出屏幕一圈以覆盖旋转后的画布
            for (float y = -h; y < 2 * h; y += spacingY) {
                for (float x = -w; x < 2 * w; x += spacingX) {
                    // 后续行相对第一行居中：drawX = 块起点 + (块宽 - 行宽)/2
                    for (int i = 0; i < lines.length; i++) {
                        float lw = paint.measureText(lines[i]);
                        float drawX = x + (blockWidth - lw) / 2f;
                        float drawY = y + i * lineHeight;
                        canvas.drawText(lines[i], drawX, drawY, paint);
                    }
                }
            }
        } catch (Exception ignored) {
            // 绘制异常绝不外抛，避免悬浮服务崩溃
        }
    }
}
