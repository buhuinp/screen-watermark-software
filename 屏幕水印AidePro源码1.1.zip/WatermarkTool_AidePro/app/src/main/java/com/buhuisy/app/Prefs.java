package com.buhuisy.app;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * 水印参数存储。所有修改都在界面回调里立刻写入 SharedPreferences，
 * 实现“实时自动保存，无需手动保存”。
 */
public class Prefs {

    private static final String NAME = "watermark_prefs";

    // 默认水印文本（按需求改为 Text）与颜色（还原 dex 里的 #8033B5E5，8 位 ARGB，50% 透明青色）
    public static final String DEFAULT_TEXT = "Text";
    public static final int DEFAULT_COLOR = 0x8033B5E5;
    // 默认字号（dp）
    public static final int DEFAULT_FONT_SIZE = 16;

    private Prefs() {}

    public static SharedPreferences sp(Context c) {
        return c.getApplicationContext()
                .getSharedPreferences(NAME, Context.MODE_PRIVATE);
    }

    /** 读取水印文本 */
    public static String getText(Context c) {
        return sp(c).getString("watermarkText", DEFAULT_TEXT);
    }

    /** 保存水印文本 */
    public static void setText(Context c, String text) {
        sp(c).edit().putString("watermarkText", text).apply();
    }

    /** 读取水印颜色（ARGB int） */
    public static int getColor(Context c) {
        return sp(c).getInt("watermarkColor", DEFAULT_COLOR);
    }

    /** 保存水印颜色 */
    public static void setColor(Context c, int argb) {
        sp(c).edit().putInt("watermarkColor", argb).apply();
    }

    /** 读取字号（dp） */
    public static int getFontSize(Context c) {
        return sp(c).getInt("fontSize", DEFAULT_FONT_SIZE);
    }

    /** 保存字号（dp） */
    public static void setFontSize(Context c, int size) {
        sp(c).edit().putInt("fontSize", size).apply();
    }

    /** 读取自定义字体文件路径（空串 = 用系统默认字体） */
    public static String getFontPath(Context c) {
        return sp(c).getString("fontPath", "");
    }

    /** 保存自定义字体文件路径（空串 = 恢复默认字体） */
    public static void setFontPath(Context c, String path) {
        sp(c).edit().putString("fontPath", path == null ? "" : path).apply();
    }
}
