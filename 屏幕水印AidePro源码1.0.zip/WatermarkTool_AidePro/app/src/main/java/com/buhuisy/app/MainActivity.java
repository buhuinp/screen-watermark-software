package com.buhuisy.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;

/**
 * 主界面：
 *  - 进入后若没有悬浮窗权限则引导去授权；
 *  - 授权后展示水印调试参数：水印文本(可换行)、字号、调色盘、亮度、透明度、手动色号；
 *  - 授权后自动启动全局悬浮水印；
 *  - 所有参数修改实时自动保存（SharedPreferences），悬浮窗打开时同步生效。
 */
public class MainActivity extends Activity {

    private EditText etText;
    private EditText etHex;
    private View preview;
    private ColorWheelView wheel;
    private ValueSliderView valueSlider;
    private SeekBar sbSize;
    private SeekBar sbAlpha;
    private TextView tvSizeValue;
    private TextView tvAlphaValue;
    private Button btnToggle;

    // 防止程序回填 hex 时触发自身 TextWatcher 造成死循环
    private boolean updatingHex = false;

    // 本地期望状态：true=水印开启，false=水印关闭。
    // 用它驱动按钮文案与点击动作，避免受 startService/stopService 异步状态影响而写反。
    private boolean watermarkOn = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 兜底：任何异常不再直接闪退，把错误显示在屏幕上方便排查
        try {
            installCrashLogger();
            setContentView(R.layout.activity_main);

            etText = findViewById(R.id.etText);
            etHex = findViewById(R.id.etHex);
            preview = findViewById(R.id.preview);
            wheel = findViewById(R.id.wheel);
            valueSlider = findViewById(R.id.valueSlider);
            sbSize = findViewById(R.id.sbSize);
            sbAlpha = findViewById(R.id.sbAlpha);
            tvSizeValue = findViewById(R.id.tvSizeValue);
            tvAlphaValue = findViewById(R.id.tvAlphaValue);
            btnToggle = findViewById(R.id.btnToggle);

            int savedColor = Prefs.getColor(this);

            // 初始化控件状态
            etText.setText(Prefs.getText(this));

            int fontSize = Prefs.getFontSize(this);
            sbSize.setProgress(fontSize - 8);
            tvSizeValue.setText(fontSize + "dp");

            int alpha = (savedColor >>> 24) & 0xFF;
            sbAlpha.setProgress(Math.round(alpha * 100f / 255f));
            tvAlphaValue.setText(Math.round(alpha * 100f / 255f) + "%");

            wheel.setMarker(savedColor);
            valueSlider.setBaseColor(savedColor);
            float[] hsv = new float[3];
            Color.colorToHSV(savedColor, hsv);
            valueSlider.setValueSilent(hsv[2]);
            refreshHexAndPreview(savedColor);

            wireListeners();
        } catch (Throwable t) {
            showError(t);
        }
    }

    /** 把未捕获的崩溃写入 /data/data/<包名>/files/crash.log，便于排查 */
    private void installCrashLogger() {
        try {
            final Thread.UncaughtExceptionHandler def =
                    Thread.getDefaultUncaughtExceptionHandler();
            Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
                @Override
                public void uncaughtException(Thread thread, Throwable throwable) {
                    try {
                        java.io.PrintWriter pw = new java.io.PrintWriter(
                                openFileOutput("crash.log", MODE_APPEND));
                        throwable.printStackTrace(pw);
                        pw.close();
                    } catch (Exception ignored) {
                    }
                    if (def != null) def.uncaughtException(thread, throwable);
                    else android.os.Process.killProcess(android.os.Process.myPid());
                }
            });
        } catch (Throwable ignored) {
        }
    }

    /** 出错时不再闪退，直接显示错误信息 */
    private void showError(Throwable t) {
        try {
            java.io.StringWriter sw = new java.io.StringWriter();
            t.printStackTrace(new java.io.PrintWriter(sw));

            TextView tv = new TextView(this);
            tv.setTextSize(14f);
            tv.setTextColor(0xFFCC0000);
            tv.setText("启动出错（已显示错误，不再闪退）：\n\n" + t + "\n\n" + sw.toString());

            android.widget.ScrollView sv = new android.widget.ScrollView(this);
            sv.addView(tv);
            setContentView(sv);
        } catch (Throwable ignored) {
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 只负责权限：无权限则引导去授权。并校准一次水印状态。
        if (!hasOverlayPermission()) {
            requestOverlayPermission();
        }
        watermarkOn = FloatingWatermarkService.isRunning();
        updateToggleButton();
    }

    // ---------- 悬浮窗权限 ----------

    private boolean hasOverlayPermission() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M
                || Settings.canDrawOverlays(this);
    }

    private void requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Intent intent = new Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                startActivity(intent);
            } catch (Exception ignored) {
            }
        }
    }

    // ---------- 打开/关闭水印按钮 ----------

    /** 刷新顶部按钮文字：未授权显示“去授权”；否则按本地期望状态显示“打开/关闭水印” */
    private void updateToggleButton() {
        if (btnToggle == null) return;
        if (!hasOverlayPermission()) {
            btnToggle.setText(R.string.btn_request_permission);
        } else if (watermarkOn) {
            btnToggle.setText(R.string.btn_close_watermark);
        } else {
            btnToggle.setText(R.string.btn_open_watermark);
        }
    }

    /** 点击顶部按钮：未授权→去授权；已授权→按期望状态在打开/关闭水印间切换 */
    private void toggleWatermark() {
        if (!hasOverlayPermission()) {
            requestOverlayPermission();
            return;
        }
        if (watermarkOn) {
            // 当前是“关闭水印”：点了就要关闭
            try {
                stopService(new Intent(MainActivity.this, FloatingWatermarkService.class));
            } catch (Exception ignored) {
            }
            watermarkOn = false;
        } else {
            // 当前是“打开水印”：点了就要打开
            try {
                startService(new Intent(MainActivity.this, FloatingWatermarkService.class));
            } catch (Exception ignored) {
            }
            watermarkOn = true;
        }
        updateToggleButton();
    }

    // ---------- 控件回调 ----------

    private void wireListeners() {
        // 顶部按钮：手动打开/关闭水印
        btnToggle.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                toggleWatermark();
            }
        });

        // 水印文本：实时保存（回车换行即多行水印）
        etText.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) {
                Prefs.setText(MainActivity.this, s.toString());
                FloatingWatermarkService.updateNow();
            }
        });

        // 字号：实时保存
        sbSize.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                int dp = progress + 8;
                tvSizeValue.setText(dp + "dp");
                if (fromUser) {
                    Prefs.setFontSize(MainActivity.this, dp);
                    FloatingWatermarkService.updateNow();
                }
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });

        // 调色盘取色：改色相/饱和度
        wheel.setOnColorChangedListener(new ColorWheelView.OnColorChangedListener() {
            @Override
            public void onWheelChanged(float hue, float sat) {
                applyColorFromControls();
            }
        });

        // 亮度条
        valueSlider.setOnValueChangedListener(new ValueSliderView.OnValueChangedListener() {
            @Override
            public void onValueChanged(float value) {
                applyColorFromControls();
            }
        });

        // 透明度：实时保存
        sbAlpha.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                tvAlphaValue.setText(progress + "%");
                if (fromUser) {
                    applyColorFromControls();
                }
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });

        // 手动色号输入
        etHex.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) {
                if (updatingHex) return;
                String raw = s.toString();
                Integer argb = parseHex(raw);
                if (argb == null) return;

                // 只有 8 位色号才同步透明度；6 位只改颜色、透明度保持不变
                String noHash = raw.trim().replace("#", "");
                if (noHash.length() == 8) {
                    int alpha = (argb >>> 24) & 0xFF;
                    sbAlpha.setProgress(Math.round(alpha * 100f / 255f));
                    tvAlphaValue.setText(Math.round(alpha * 100f / 255f) + "%");
                }

                // 用当前透明度 + 该颜色的 RGB 合成最终颜色
                int argbFinal = (alpha() << 24) | (argb & 0xFFFFFF);
                wheel.setMarker(argbFinal);
                valueSlider.setBaseColor(argbFinal);
                float[] hsv = new float[3];
                Color.colorToHSV(argbFinal, hsv);
                valueSlider.setValueSilent(hsv[2]);
                applyColor(argbFinal);
            }
        });
    }

    // ---------- 颜色合成 ----------

    /** 当前透明度（0..255），由透明度滑块换算 */
    private int alpha() {
        return Math.round(sbAlpha.getProgress() * 255f / 100f);
    }

    /** 由调色盘色相/饱和度 + 亮度条合成颜色（透明度取滑块值）并应用 */
    private void applyColorFromControls() {
        int rgb = Color.HSVToColor(new float[]{
                wheel.getHue(), wheel.getSat(), valueSlider.getValue()});
        int argb = (alpha() << 24) | (rgb & 0xFFFFFF);
        applyColor(argb);
    }

    /** 应用颜色：更新预览、hex 输入框、保存、实时刷新悬浮窗 */
    private void applyColor(int argb) {
        refreshHexAndPreview(argb);
        Prefs.setColor(this, argb);
        FloatingWatermarkService.updateNow();
    }

    /** 回填 hex 与预览（不发保存，避免与 applyColor 重复） */
    private void refreshHexAndPreview(int argb) {
        updatingHex = true;
        etHex.setText(toHex(argb));
        etHex.setSelection(etHex.getText().length());
        updatingHex = false;

        // 预览显示不透明版，便于看清实际颜色
        preview.setBackgroundColor(0xFF000000 | (argb & 0xFFFFFF));
    }

    // ---------- hex 解析 ----------

    private static String toHex(int argb) {
        int a = (argb >>> 24) & 0xFF;
        if (a == 0xFF) {
            return String.format("#%06X", argb & 0xFFFFFF);
        }
        return String.format("#%08X", argb);
    }

    /** 支持 #RRGGBB / RRGGBB / #AARRGGBB / AARRGGBB，返回 ARGB int，非法返回 null */
    private static Integer parseHex(String s) {
        if (s == null) return null;
        String h = s.trim();
        if (h.startsWith("#")) h = h.substring(1);
        if (h.length() != 6 && h.length() != 8) return null;
        try {
            long v = Long.parseLong(h, 16);
            if (h.length() == 6) {
                return 0xFF000000 | (int) v;
            }
            return (int) v;
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
