package com.buhuisy.app;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.WindowManager;

/**
 * 全局悬浮水印服务：把 WatermarkView 以 SYSTEM 悬浮层盖在所有应用之上。
 * 授权后自动启动；参数修改时通过 updateNow() 实时刷新。
 * 内部对权限、悬浮层添加等做了防御处理，避免任何一步失败导致进程崩溃。
 */
public class FloatingWatermarkService extends Service {

    private static FloatingWatermarkService instance;

    private WindowManager windowManager;
    private WatermarkView watermarkView;
    // 记录悬浮层是否真正挂载成功，避免 onDestroy 重复移除导致崩溃
    private boolean attached = false;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createOverlay();
    }

    private void createOverlay() {
        try {
            int type;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
            } else {
                type = WindowManager.LayoutParams.TYPE_PHONE;
            }

            WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    type,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
            params.gravity = Gravity.TOP | Gravity.START;

            watermarkView = new WatermarkView(this);
            watermarkView.setWatermarkText(Prefs.getText(this));
            watermarkView.setWatermarkColor(Prefs.getColor(this));
            watermarkView.setWatermarkFontSize(Prefs.getFontSize(this));

            windowManager.addView(watermarkView, params);
            attached = true;
        } catch (Exception e) {
            // 权限被收回或悬浮层创建失败：不崩溃，服务继续存活
            attached = false;
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        refresh();
        return START_STICKY;
    }

    /** 是否正在运行（主界面用来判断是否需要自动启动） */
    public static boolean isRunning() {
        return instance != null;
    }

    /** 主界面参数变化时调用：实时更新悬浮水印 */
    public static void updateNow() {
        if (instance != null) {
            instance.refresh();
        }
    }

    private void refresh() {
        try {
            if (watermarkView != null) {
                watermarkView.setWatermarkText(Prefs.getText(this));
                watermarkView.setWatermarkColor(Prefs.getColor(this));
                watermarkView.setWatermarkFontSize(Prefs.getFontSize(this));
            }
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onDestroy() {
        if (watermarkView != null && attached) {
            try {
                windowManager.removeView(watermarkView);
            } catch (Exception ignored) {
            }
        }
        watermarkView = null;
        attached = false;
        instance = null;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
