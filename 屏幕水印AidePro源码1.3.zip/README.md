# 屏幕水印（Aide Pro 可编译）

应用名：屏幕水印 ／ 包名：`com.buhuisy.app`

## 一、水印模块分析结论

1. 入口 `init(Context)`：注册 `ActivityLifecycleCallbacks`，随后调用
   `enableGlobalWatermark("World Box-不会破解")` 写入默认水印文本。
2. `enableGlobalWatermark(text)`：`trim()` 去空格、判空后存入静态字段
   `watermarkText`，再 post 到主线程。
3. 主线程里 `getTopActivityByReflection()`：反射 `android.app.ActivityThread`
   的 `mActivities`，取第一个 `paused == false` 的 Activity（即当前顶部界面）。
4. `addWatermarkToActivity(Activity)`：取 `decorView`，若已存在 tag 为
   `DEX_WATERMARK` 的视图则跳过（去重）；否则 `addView` 一个全屏
   `WatermarkView`，`LayoutParams(FILL_PARENT, FILL_PARENT)`，
   `clickable/focusable = false`（不挡触摸）。
5. `WatermarkView` 绘制：
   - `Paint.setColor(Color.parseColor("#8033B5E5"))` —— 8 位 ARGB：
     `0x80` = 50% 透明，`33B5E5` = 青色。
   - `setTextSize(dp(16))`、抗锯齿。
   - `onDraw`：`canvas.rotate(-45°, 中心)`，间距 = `文本宽/高 + dp(60)`，
     从 `(-w, -h)` 平铺到 `(2w, 2h)` 循环 `drawText`。

## 二、本工程实现的功能

- 进入后申请悬浮窗权限（`SYSTEM_ALERT_WINDOW`），授权后自动启动全局悬浮水印
  并显示调试面板（无顶部开关按钮）。
- 默认水印文本为 `Text`。
- 调试参数：
  - 水印文本：EditText 可修改，**回车换行支持多行**，同块内后续行按第一行居中。
  - 字号：滑块调节（8–60dp，默认 16dp）。
  - 水印颜色：HSV 调色盘（色相 + 饱和度）+ 亮度条取色。
  - 透明度：滑块调节（0–100%），作为颜色 alpha，默认 50%。
  - 手动色号：支持 `#RRGGBB` / `#AARRGGBB` 输入（6 位只改颜色、8 位同时同步透明度）。
- 实时自动保存：文本/字号/取色/透明度/色号一改即写入 `SharedPreferences`；
  若水印已打开则同步刷新，无需手动保存按钮。

## 三、在 Aide Pro 中编译

1. 把整个 `WatermarkTool_AidePro` 文件夹导入 Aide Pro（File → Open 选中该目录）。
2. 打开 `app/build.gradle`，若报 Gradle 插件版本问题，把根目录 `build.gradle`
   里的 `classpath 'com.android.tools.build:gradle:7.4.2'` 换成 Aide 内置版本号，
   或删除 `buildscript` 块让 Aide 使用默认配置。
3. Run / Build 生成 APK，安装到手机。
4. 首次进入点“去授权悬浮窗权限”，授予后即可打开水印并调试参数。

> 说明：工程不引入任何第三方库，纯系统框架，离线可编译。
