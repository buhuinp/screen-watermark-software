package com.buhuisy.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;

import java.io.File;

/**
 * 水印绘制视图：还原 dex 中 com.dex.init$WatermarkView 的绘制算法并扩展。
 *  1. 颜色 = 调色盘取色（ARGB），抗锯齿，字号/字体可调
 *  2. 支持 5 种样式：0↗↙斜(-45°平铺原版) 1↖↘斜(45°) 2横向 3竖向 4单个居中
 *  3. 支持多行文本（\\n 换行），同一文本块内后续行按第一行居中
 *  4. 渐变色：开启后每个文本块内部从左到右线性渐变（左=当前色，右=当前色互补色）
 * 它同时被用于悬浮窗覆盖层（全局）显示。
 */
public class WatermarkView extends View {

    private Paint paint;
    private String text;
    private Typeface typeface = Typeface.DEFAULT;
    private int style;                 // 0..4
    private boolean gradientEnabled;   // true=多彩渐变从左向右流动
    private float startHue;            // 渐变起始色相，随机起点，随时间流动
    private final Handler handler = new Handler(Looper.getMainLooper());

    public WatermarkView(Context context) {
        super(context);
        init(context);
    }

    public WatermarkView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    private void init(Context context) {
        paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        text = Prefs.getText(context);
        paint.setColor(Prefs.getColor(context));
        paint.setTextSize(dp(context, Prefs.getFontSize(context)));
        paint.setAntiAlias(true);
        paint.setTypeface(typeface);
        setWatermarkFont(Prefs.getFontPath(context));
        style = Prefs.getStyle(context);
        gradientEnabled = Prefs.getGradientEnabled(context);
        setClickable(false);
        setFocusable(false);
    }

    /** 更新水印文本（悬浮窗打开时实时生效） */
    public void setWatermarkText(String t) {
        this.text = t;
        invalidate();
    }

    /** 更新水印颜色（ARGB），实时生效 */
    public void setWatermarkColor(int argb) {
        paint.setColor(argb);
        invalidate();
    }

    /** 更新字号（dp），实时生效 */
    public void setWatermarkFontSize(int dp) {
        paint.setTextSize(dp(getContext(), dp));
        invalidate();
    }

    /** 应用自定义字体：path 为空或文件不存在则回退到系统默认字体 */
    public void setWatermarkFont(String path) {
        try {
            Typeface tf = Typeface.DEFAULT;
            if (path != null && !path.isEmpty()) {
                File f = new File(path);
                if (f.exists()) {
                    tf = Typeface.createFromFile(f);
                }
            }
            typeface = tf;
            paint.setTypeface(tf);
            invalidate();
        } catch (Exception ignored) {
            try {
                paint.setTypeface(Typeface.DEFAULT);
            } catch (Exception ignored2) {
            }
        }
    }

    /** 设置水印样式：0↗↙斜 1↖↘斜 2横向 3竖向 4单个居中 */
    public void setWatermarkStyle(int s) {
        this.style = s;
        invalidate();
    }

    /** 设置渐变色开关：true=多彩随机渐变颜色带从文本左侧缓慢流向右端 */
    public void setGradientEnabled(boolean on) {
        this.gradientEnabled = on;
        if (on) {
            startHue = (float) (Math.random() * 360f); // 随机起始色相，多种颜色
            handler.removeCallbacks(gradientRunnable);
            handler.post(gradientRunnable);
        } else {
            handler.removeCallbacks(gradientRunnable);
            paint.setShader(null);
            paint.setColor(Prefs.getColor(getContext()));
            invalidate();
        }
    }

    private final Runnable gradientRunnable = new Runnable() {
        @Override
        public void run() {
            if (!gradientEnabled) return;
            startHue += 2f;
            if (startHue > 360f) startHue -= 360f;
            invalidate();
            handler.postDelayed(this, 40);
        }
    };

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        handler.removeCallbacks(gradientRunnable);
    }

    private float dp(Context ctx, int value) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value,
                ctx.getResources().getDisplayMetrics());
    }

    @Override
    protected void onDraw(Canvas canvas) {
        try {
            super.onDraw(canvas);
            if (text == null || text.isEmpty()) {
                return;
            }

            int w = getWidth();
            int h = getHeight();
            if (w <= 0 || h <= 0) {
                return;
            }

            String[] lines = text.split("\\n");
            Paint.FontMetrics fm = paint.getFontMetrics();
            float lineHeight = fm.descent - fm.ascent;
            if (lineHeight <= 0) lineHeight = paint.getTextSize();

            float blockWidth = 0f;
            for (String line : lines) {
                float lw = paint.measureText(line);
                if (lw > blockWidth) blockWidth = lw;
            }
            float blockHeight = Math.max(lines.length * lineHeight, lineHeight);

            // 单个居中样式：只画一个，屏幕水平垂直居中
            if (style == 4) {
                float topY = h / 2f - blockHeight / 2f;
                float baseY = topY - fm.ascent;
                float x = (w - blockWidth) / 2f;
                applyGradientShader(gradientEnabled, x, baseY, x + blockWidth, baseY);
                for (int i = 0; i < lines.length; i++) {
                    float lw = paint.measureText(lines[i]);
                    float drawX = x + (blockWidth - lw) / 2f;
                    canvas.drawText(lines[i], drawX, baseY + i * lineHeight, paint);
                }
                paint.setShader(null);
                return;
            }

            // 斜向/横向/竖向：统一用旋转 + 平铺
            float angle;
            switch (style) {
                case 1: angle = 45f; break;
                case 2: angle = 0f; break;
                case 3: angle = 90f; break;
                default: angle = -45f; break;
            }
            canvas.rotate(angle, w / 2f, h / 2f);

            float spacingX = blockWidth + dp(getContext(), 60);
            float spacingY = blockHeight + dp(getContext(), 60);
            if (spacingX <= 0) spacingX = 1f;
            if (spacingY <= 0) spacingY = 1f;

            for (float y = -h; y < 2 * h; y += spacingY) {
                for (float x = -w; x < 2 * w; x += spacingX) {
                    // 每个文本块各自：多彩渐变从左向右流动
                    applyGradientShader(gradientEnabled, x, y, x + blockWidth, y);
                    for (int i = 0; i < lines.length; i++) {
                        float lw = paint.measureText(lines[i]);
                        float drawX = x + (blockWidth - lw) / 2f;
                        float drawY = y + i * lineHeight;
                        canvas.drawText(lines[i], drawX, drawY, paint);
                    }
                }
            }
            paint.setShader(null);
        } catch (Exception ignored) {
            // 绘制异常绝不外抛，避免悬浮服务崩溃
        }
    }

    /**
     * 开启渐变时为 paint 设置多彩渐变 shader：
     * 在当前透明度下，用多种随机色相颜色从左到右渐变，整条色带随时间向右流动；关闭则清空。
     */
    private void applyGradientShader(boolean grad, float x0, float y0, float x1, float y1) {
        if (!grad) {
            paint.setShader(null);
            return;
        }
        try {
            int base = Prefs.getColor(getContext());
            int alpha = (base >>> 24) & 0xFF;
            float[] hsv = new float[3];
            Color.colorToHSV(base, hsv);
            float sat = hsv[1], val = hsv[2];

            int count = 6;
            int[] colors = new int[count];
            float[] pos = new float[count];
            for (int i = 0; i < count; i++) {
                float hue = startHue + i * (360f / count);
                if (hue > 360f) hue -= 360f;
                int rgb = Color.HSVToColor(new float[]{hue, sat, val});
                colors[i] = (alpha << 24) | (rgb & 0xFFFFFF);
                pos[i] = i / (float) (count - 1);
            }
            paint.setShader(new LinearGradient(x0, y0, x1, y1, colors, pos,
                    Shader.TileMode.CLAMP));
        } catch (Exception ignored) {
            paint.setShader(null);
        }
    }
}
